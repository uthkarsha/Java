package Code;
// The GraphLoader class handles the initialization of the graph.
// Responsibilities:
// 1. Provide methods to create and populate a graph with sample data.
// 2. Serve as a utility class for setting up predefined graph structures.
public class GraphLoader {
    // Static method to load a sample graph.
    // Returns: A fully populated Graph object.
	 public static Graph loadSampleGraph() {
	        Graph graph = new Graph();
	        // Add vertices
	        graph.addVertex("A");
	        graph.addVertex("B");
	        graph.addVertex("C");
	        graph.addVertex("D");
	        graph.addVertex("E");
	        graph.addVertex("F");

	        // Add edges
	        graph.addEdge("A", "B", 5, 10, 3);
	        graph.addEdge("A", "C", 7, 15, 5);
	        graph.addEdge("B", "D", 3, 6, 2);
	        graph.addEdge("C", "D", 2, 5, 4);
	        graph.addEdge("C", "E", 8, 12, 6);
	        graph.addEdge("D", "F", 6, 9, 4);
	        graph.addEdge("E", "F", 4, 8, 3);

	        return graph;
	    }
    public static Graph loadSampleGraph2() {
        // Create a new Graph instance.
        Graph graph = new Graph();

        // Add vertices to the graph.
        // Example: graph.addVertex("A");
        graph.addVertex("X");
        graph.addVertex("Y");

        // Add edges with weights (distance, time, cost).
        // Example: graph.addEdge("A", "B", 5, 10, 3);
        graph.addEdge("X", "Y", 3, 5, 2);

        // Return the populated graph.
        return graph;
    }
    
    
    // Create two more methods to load graphs
    public static Graph loadSampleGraph3() {
        Graph graph = new Graph();
        graph.addVertex("P");
        graph.addVertex("Q");
        graph.addEdge("P", "Q", 3, 6, 2);
        return graph;
    }
}