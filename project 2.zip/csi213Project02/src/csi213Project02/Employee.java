package csi213Project02;

/**
 * This {@code Employee} abstract base class to assign numbers for the employees.
 */
public abstract class Employee {
 // track the next employee ID
 private static int nextEmployeeId = 1;
 
 // employee ID, first name, and last name
 private int employeeId;
 private String firstName;
 private String lastName;

 // initializing first and last name, assigns employee ID
 public Employee(String firstName, String lastName) {
     this.firstName = firstName;
     this.lastName = lastName;
     this.employeeId = nextEmployeeId++; // Increment ID for the next employee
 }

 // employee ID
 public int getEmployeeId() {
     return employeeId;
 }

 // Accessor first name
 public String getFirstName() {
     return firstName;
 }

 // Mutator for first name
 public void setFirstName(String firstName) {
     this.firstName = firstName;
 }

 // Accessor for last name
 public String getLastName() {
     return lastName;
 }

 // Mutator for last name
 public void setLastName(String lastName) {
     this.lastName = lastName;
 }

 // Returns a string representation of the employee
 @Override
 public String toString() {
     return "Id:" + employeeId + " - " + lastName + ", " + firstName;
 }

 //  get the paycheck amount, to be implemented by subclasses
 public abstract float getPaycheck();
}
