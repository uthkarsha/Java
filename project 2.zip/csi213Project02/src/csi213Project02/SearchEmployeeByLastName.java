package csi213Project02;

import java.util.Scanner;
/**
 * {@code SearchEmployeeByLastName} allows searching for employees based on last name.
 */
public class SearchEmployeeByLastName {

    /**
     * Executes the search by last name and prints matching employee details.
     *
     * @param employees Array of employees to search.
     * @param employeeCount The number of employees currently in the system.
     */
    public void execute(Employee[] employees, int employeeCount) {
        System.out.print("Enter Last Name: ");
        Scanner scanner = new Scanner(System.in);
        String lastName = scanner.nextLine();

        for (Employee employee : employees) {
            if (employee != null && employee.getLastName().equalsIgnoreCase(lastName)) {
                System.out.println(employee);
            }
        }
    }
}