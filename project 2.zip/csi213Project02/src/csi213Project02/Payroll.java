package csi213Project02;

import java.util.Scanner;

/**
 * The {@code Payroll} class manages the main payroll menu and allows interaction with other functionality classes.
 */
public class Payroll {
    private Employee[] employees = new Employee[50];
    private int employeeCount = 0;
    private Scanner scanner = new Scanner(System.in);

    /**
     * Main method to start the Payroll system.
     *
     * @param args Command-line arguments (not used).
     */
    public static void main(String[] args) {
        Payroll payroll = new Payroll();
        payroll.displayMenu();
    }

    /**
     * Displays the menu and interacts with user choices.
     */
    public void displayMenu() {
        int choice;
        do {
            System.out.println("\nPayroll System Menu:");
            System.out.println("1) Create an Employee");
            System.out.println("2) Search for an Employee by Last Name");
            System.out.println("3) Display an Employee by Employee Number");
            System.out.println("4) Run Payroll");
            System.out.println("5) Quit");
            System.out.print("Enter choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1 -> new CreateEmployee().execute(employees, this);
                case 2 -> new SearchEmployeeByLastName().execute(employees, employeeCount);
                case 3 -> new DisplayEmployeeByNumber().execute(employees, employeeCount);
                case 4 -> new RunPayroll().execute(employees, employeeCount, scanner);
                case 5 -> System.out.println("Exiting Payroll System.");
                default -> System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 5);
    }

    /**
     * Adds an employee to the list and increments the count.
     *
     * @param employee The employee to add.
     */
    public void addEmployee(Employee employee) {
        employees[employeeCount++] = employee;
    }
}
