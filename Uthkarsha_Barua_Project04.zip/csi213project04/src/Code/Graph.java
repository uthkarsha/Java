package Code;
import java.util.*;

// The Graph class represents the entire graph structure.
// Responsibilities:
// 1. Store vertices and edges using an adjacency list.
// 2. Provide methods for adding/removing vertices and edges.
// 3. Implement algorithms like Dijkstra's for shortest path calculations.
public class Graph {
	// Adjacency list to store the graph. Each vertex maps to a list of connected
	// edges.
	private Map<String, List<Edge>> adjList;

	// Constructor: Initializes the adjacency list.
	public Graph() {
		// Initialize the adjacency list as a HashMap.
		adjList = new HashMap<>();
	}

	// Adds a vertex to the graph.
	// Parameter: vertex - The name of the vertex to add.
	public void addVertex(String vertex) {
		// If the vertex does not already exist, add it to the adjacency list.
		if (!adjList.containsKey(vertex)) {
            adjList.put(vertex, new ArrayList<>());
        }
	}

	// Adds an edge to the graph.
	// Parameters:
	// - source: The starting vertex of the edge.
	// - destination: The ending vertex of the edge.
	// - distance, time, cost: Weights associated with this edge.
	public void addEdge(String source, String destination, int distance, int time, int cost) {
		// Add the edge to both source and destination vertices since this is an
		// undirected graph.
		 addVertex(source);
	        addVertex(destination);
	        adjList.get(source).add(new Edge(destination, distance, time, cost));
	        adjList.get(destination).add(new Edge(source, distance, time, cost)); // for undirected graph
	    }

	// Dijkstra's algorithm to compute shortest paths from a given start vertex.
	// Parameters:
	// - start: The starting vertex.
	// - weightType: The weight type to use for path calculation ("distance",
	// "time", "cost").
	// Returns: A map of vertices and their shortest distances from the start
	// vertex.
	public Map<String, Integer> dijkstra(String start, String weightType) {
		// Step 1: Initialize the data structures for Dijkstra's algorithm.

		// Map to store the shortest distance from the start vertex to each other
		// vertex.
		// Initially, all distances are set to Integer.MAX_VALUE (infinity).

		// Priority queue (min-heap) to process vertices in the order of their current
		// shortest distance.
		// The priority queue will store edges, where the weight corresponds to the
		// distance from the start vertex.

		// Set to keep track of visited vertices, ensuring each vertex is processed only
		// once using a HashSet.

		// Step 2: Initialize distances for all vertices.
		// Set all distances to infinity and the start vertex's distance to 0.
		// Add the start vertex to the priority queue with a distance of 0.

		// Step 3: Process the priority queue until it is empty.
		// While there are still vertices to process in the priority queue:

		// Extract the edge with the smallest weight (minimum distance) from the
		// priority queue.

		// If the current vertex has already been visited, skip it.

		// Mark the current vertex as visited.

		// Step 4: Update the distances for the neighbors of the current vertex.
		// For each neighbor of the current vertex:

		// Skip any neighbors that have already been visited.

		// Calculate the new potential distance to the neighbor.

		// If the new distance is smaller than the currently known distance, update it.

		// Add the neighbor to the priority queue with its updated distance.

		// Step 5: Return the map of shortest distances.
		Map<String, Integer> distances = new HashMap<>();
        PriorityQueue<String> pq = new PriorityQueue<>(Comparator.comparingInt(distances::get));
        Set<String> visited = new HashSet<>();

        // Initialize distances
        for (String vertex : adjList.keySet()) {
            distances.put(vertex, Integer.MAX_VALUE);
        }
        distances.put(start, 0);
        pq.add(start);

        while (!pq.isEmpty()) {
            String current = pq.poll();
            if (visited.contains(current)) continue;
            visited.add(current);

            for (Edge edge : adjList.get(current)) {
                String neighbor = edge.getVertex(); // Use the getter here
                if (!visited.contains(neighbor)) {
                    int newDist = distances.get(current) + edge.getWeightByType(weightType);
                    if (newDist < distances.get(neighbor)) {
                        distances.put(neighbor, newDist);
                        pq.add(neighbor);
                    }
                }
            }
        }
        return distances;
    }

	// Displays the graph in a readable format for debugging or visualization.
	public void displayGraph() {
		// Iterate through the adjacency list and print each vertex and its connected
		// edges.
		 for (String vertex : adjList.keySet()) {
	            System.out.println(vertex + " -> " + adjList.get(vertex));
	        }
	    }
	}