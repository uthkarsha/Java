package Code;
// The Edge class represents a connection between two vertices in the graph.
// Responsibilities:
// 1. Store the destination vertex of the edge.
// 2. Store multiple weights for the edge (distance, time, cost).
// 3. Provide methods to retrieve specific weights.
public class Edge {
    // The destination vertex that this edge points to.
    private String vertex;

    // Weights associated with this edge.
    private int distance;
    private int time;
    private int cost;

    // Constructor: Initializes the edge with the destination vertex and weights.
    // Parameters:
    // - vertex: The destination vertex.
    // - distance, time, cost: Weights for the edge.
    public Edge(String vertex, int distance, int time, int cost) {
        // Initialize all instance variables.
    	this.vertex = vertex;
        this.distance = distance;
        this.time = time;
        this.cost = cost;
    }
    // Getter for the vertex field.
    public String getVertex() {
        return vertex;
    }

    // Returns the weight of the edge based on the given weight type.
    // Parameter: weightType - The type of weight to retrieve ("distance", "time", "cost").
    // Returns: The weight value as an integer.
    public int getWeightByType(String weightType) {
        // Use a switch statement to return the appropriate weight based on weightType.
    	switch (weightType.toLowerCase()) {
        case "distance":
            return distance;
        case "time":
            return time;
        case "cost":
            return cost;
        default:
            throw new IllegalArgumentException("Invalid weight type: " + weightType);
    }
}

    // Returns a string representation of the edge for debugging or display purposes.
    // Example format: "B (distance: 5, time: 10, cost: 3)"
    @Override
    public String toString() {
        return vertex + " (distance: " + distance + ", time: " + time + ", cost: " + cost + ")";
    }
}