package csi213project01;
/**
 * This {@code SalariedEmploye} subclass of employee for the salaries to be paid at a set of sum per year.
 */
public class SalariedEmployee extends Employee {
 //  yearly salary
 private float yearlySalary;

 // initializing names and yearly salary
 public SalariedEmployee(String firstName, String lastName, float yearlySalary) {
     super(firstName, lastName); // Call to the superclass constructor
     this.yearlySalary = yearlySalary; // Set the yearly salary
 }

 // Accessor for yearly salary
 public float getYearlySalary() {
     return yearlySalary;
 }

 // Mutator for yearly salary
 public void setYearlySalary(float yearlySalary) {
     this.yearlySalary = yearlySalary;
 }

 // paycheck amount for salaried employees
 @Override
 public float getPaycheck() {
     return yearlySalary / 26; // Assume 26 pay periods in a year
 }

 // Returns a string representation of the salaried employee
 @Override
 public String toString() {
     return "Salaried, Base : $" + yearlySalary + "; " + super.toString();
 }
}

