package proj3Code;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class PlaylistArrayList {
	private ArrayList<Song> playlist;

	public PlaylistArrayList() {
		playlist = new ArrayList<>();
	}

	public void addSong(Song song) {
		// TODO: Add a song to the end of the playlist
		 playlist.add(song);
	}

	public void insertSong(int index, Song song) {
		// TODO: Insert a song at the specified index in the playlist
		  playlist.add(index, song);
	}

	public void removeSong(int index) {
		// TODO: Remove the song at the specified index from the playlist
		playlist.remove(index);
	}

	public Song getSong(int index) {
		// TODO: Return the song at the specified index, or null if the index is invalid
		return playlist.get(index);
	}

	public void shuffle() {
		// TODO: Shuffle the playlist
		Collections.shuffle(playlist);
	}

	public void sortByTitle() {
		// TODO: Sort the playlist by song title
		 playlist.sort((a, b) -> a.getTitle().compareToIgnoreCase(b.getTitle()));
	}

	public void sortByArtist() {
		// TODO: Sort the playlist by artist name
		playlist.sort((a, b) -> a.getArtist().compareToIgnoreCase(b.getArtist()));
	}

	public void sortByDuration() {
		// TODO: Sort the playlist by duration
		playlist.sort((a, b) -> Integer.compare(a.getDuration(), b.getDuration()));
	}

	public int searchByTitle(String title) {
		// TODO: Search for a song by title and return its index, or -1 if not found
		for (int i = 0; i < playlist.size(); i++) {
            if (playlist.get(i).getTitle().equalsIgnoreCase(title)) {
                return i;
            }
        }
		return -1;
	}

	public int searchByArtist(String artist) {
		// TODO: Search for a song by artist and return its index, or -1 if not found
		  for (int i = 0; i < playlist.size(); i++) {
	            if (playlist.get(i).getArtist().equalsIgnoreCase(artist)) {
	                return i;
	            }
	        }
		return -1;
	}

	public void printPlaylist() {
		// TODO: Print all songs in the playlist
		 for (Song song : playlist) {
	            System.out.println(song);
	        }
	    }
	}
