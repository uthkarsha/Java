package csi213Project02;

/**
 * This {@code HourlyEmployee} subclass of employee who are paid by the fractional hour at a set rate. .
 */
public class HourlyEmployee extends Employee {
 // variables for pay rate and hours worked
 private float payRate;
 private float hoursWorked;

 // initializing names and pay rate
 public HourlyEmployee(String firstName, String lastName, float payRate) {
     super(firstName, lastName); // Calling  the superclass 
     this.payRate = payRate; // Set the pay rate
     this.hoursWorked = 0; // Initializing hours worked to 0
 }

 // Accessor for pay rate
 public float getPayRate() {
     return payRate;
 }

 // Mutator for pay rate
 public void setPayRate(float payRate) {
     this.payRate = payRate;
 }

 // Accessor for hours worked
 public float getHoursWorked() {
     return hoursWorked;
 }

 // Mutator for hours worked
 public void setHoursWorked(float hoursWorked) {
     this.hoursWorked = hoursWorked; // Update hours worked
 }

 // paycheck amount for hourly employees
 @Override
 public float getPaycheck() {
     return hoursWorked * payRate; // Paycheck = hours worked * pay rate
 }

 // Returns a string representation of the hourly employee
 @Override
 public String toString() {
     return "Hourly: $" + payRate + "; " + super.toString();
 }
}
