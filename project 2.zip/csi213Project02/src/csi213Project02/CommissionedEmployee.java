package csi213Project02;

import csi213Project02.SalariedEmployee;

/**
 * This {@code CommissionEmployee} subclass of employees who has a commission schedule.
 */
public class CommissionedEmployee extends SalariedEmployee {
 // variables for commission schedule and units sold
 private float[][] commissionSchedule;
 private float unitsSold;

 // initializing names, yearly salary, and commission schedule
 public CommissionedEmployee(String firstName, String lastName, float yearlySalary, float[][] commissionSchedule) {
     super(firstName, lastName, yearlySalary); // Call to the superclass constructor
     this.commissionSchedule = commissionSchedule; // Set the commission schedule
     this.unitsSold = 0; // Initialize units sold to 0
 }

 // Accessor for units sold
 public float getUnitsSold() {
     return unitsSold;
 }

 // Mutator for units sold
 public void setUnitsSold(float unitsSold) {
     this.unitsSold = unitsSold; // Update units sold
 }

 // Accessor for commission schedule
 public float[][] getCommissionSchedule() {
     return commissionSchedule;
 }

 // Mutator for commission schedule
 public void setCommissionSchedule(float[][] commissionSchedule) {
     this.commissionSchedule = commissionSchedule; // Update commission schedule
 }

 // paycheck amount for commissioned employees
 @Override
 public float getPaycheck() {
     float basePay = super.getPaycheck(); // Get base pay
     float bestCommissionRate = 0; // Variable to store the best commission rate

     // Iteration for commission schedule to find the best rate
     for (float[] schedule : commissionSchedule) {
         if (unitsSold >= schedule[0]) { // Check if units sold meets the minimum
             bestCommissionRate = Math.max(bestCommissionRate, schedule[1]); // Update best rate
         }
     }

     // paycheck including commissions
     return basePay + (unitsSold * bestCommissionRate);
 }

 // Returns a string representation of the commissioned employee
 @Override
 public String toString() {
     return "Commission: Base : $" + getYearlySalary() + "; " + super.toString();
 }
}