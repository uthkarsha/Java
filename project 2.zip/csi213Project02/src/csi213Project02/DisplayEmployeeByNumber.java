package csi213Project02;

import java.util.Scanner;
/**
 * {@code DisplayEmployeeByNumber} displays an employee's details based on their employee ID.
 */
public class DisplayEmployeeByNumber {

    /**
     * Executes the display by employee number search.
     *
     * @param employees Array of employees to search.
     * @param employeeCount The number of employees currently in the system.
     */
    public void execute(Employee[] employees, int employeeCount) {
        System.out.print("Enter Employee Number: ");
        Scanner scanner = new Scanner(System.in);
        int empNumber = scanner.nextInt();

        for (Employee employee : employees) {
            if (employee != null && employee.getEmployeeId() == empNumber) {
                System.out.println(employee);
                return;
            }
        }
        System.out.println("Employee not found.");
    }
}