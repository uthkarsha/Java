package csi213project01;
/**
 * {@code Main} tests the Project01 implementations.
 * 
 * @author Uthkarsha Barua (ubarua@albany.edu)
 * 
 */
public class Main {
 public static void main(String[] args) {
     // test Salaried Employee
     SalariedEmployee salariedEmployee = new SalariedEmployee("Uthkarsha", "Barua", 100000);
     System.out.println(salariedEmployee); // Print employee details
     System.out.println("Paycheck: $" + salariedEmployee.getPaycheck()); // Print paycheck amount

     // test Hourly Employee
     HourlyEmployee hourlyEmployee = new HourlyEmployee("Sadman", "Sakib", 15.25f);
     hourlyEmployee.setHoursWorked(25.5f); // Set hours worked for this pay period
     System.out.println(hourlyEmployee); // Print employee details
     System.out.println("Paycheck: $" + hourlyEmployee.getPaycheck()); // Print paycheck amount

     // test Commissioned Employee
     float[][] commissionSchedule = {
         {0.0f, 2.5f},
         {12.0f, 3.2f},
         {25.0f, 4.1f},
         {33.0f, 4.9f},
         {42.0f, 5.2f}
     };
     CommissionedEmployee commissionedEmployee = new CommissionedEmployee("Shashank", "Arora", 100000, commissionSchedule);
     commissionedEmployee.setUnitsSold(20); // Set units sold
     System.out.println(commissionedEmployee); // Print employee details
     System.out.println("Paycheck: $" + commissionedEmployee.getPaycheck()); // Print paycheck amount
 }
}
