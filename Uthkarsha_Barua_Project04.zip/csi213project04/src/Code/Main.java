package Code;
import java.util.*;

// The Main class serves as the entry point of the program.
// Responsibilities:
// 1. Interact with the user to take inputs and display outputs.
// 2. Use the Graph and related classes to perform tasks like finding shortest paths.
public class Main {
    public static void main(String[] args) {
        // Create a Scanner object to handle user input.
        Scanner scanner = new Scanner(System.in);

        // Load a predefined graph using the GraphLoader class.
        Graph graph = GraphLoader.loadSampleGraph();

        // Display the graph structure to the user.
        System.out.println("City Map (Graph):");
        graph.displayGraph();

        // Ask the user for the start and end locations.
        System.out.print("Enter start location: ");
        String start = scanner.nextLine();
        System.out.print("Enter end location: ");
        String end = scanner.nextLine();

        // Ask the user for the weight type to use for the shortest path calculation.
        System.out.print("Select weight type (distance/time/cost): ");
        String weightType = scanner.nextLine();

        // Use Dijkstra's algorithm to calculate the shortest path.
        try {
            Map<String, Integer> distances = graph.dijkstra(start, weightType);

            // Display the shortest path result to the user.
            if (distances.containsKey(end)) {
                System.out.println("Shortest " + weightType + " from " + start + " to " + end + ": " + distances.get(end));
            } else {
                System.out.println("One or both locations not found in the map.");
            }
        } catch (IllegalArgumentException e) {
            // Handle invalid weight type errors.
            System.out.println(e.getMessage());
        }

        // Close the Scanner object to prevent resource leaks.
        scanner.close();
    }
}
