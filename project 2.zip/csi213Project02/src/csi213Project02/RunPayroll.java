package csi213Project02;

import java.util.Scanner;

/**
 * {@code RunPayroll} calculates and displays the paycheck for each employee.
 */
public class RunPayroll {

    /**
     * Executes the payroll calculation, displaying each employee's paycheck.
     *
     * @param employees Array of employees to process.
     * @param employeeCount The number of employees currently in the system.
     * @param scanner The scanner object for input.
     */
    public void execute(Employee[] employees, int employeeCount, Scanner scanner) {
        for (Employee employee : employees) {
            if (employee instanceof HourlyEmployee hourlyEmployee) {
                System.out.print("Enter hours worked for " + hourlyEmployee.getFirstName() + ": ");
                hourlyEmployee.setHoursWorked(scanner.nextFloat());
            } else if (employee instanceof CommissionedEmployee commissionedEmployee) {
                System.out.print("Enter units sold for " + commissionedEmployee.getFirstName() + ": ");
                commissionedEmployee.setUnitsSold(scanner.nextFloat());
            }
        }

        // Displaying paycheck information
        System.out.println("Payroll:");
        for (Employee employee : employees) {
            if (employee != null) {
                System.out.printf("%s %10.2f%n", employee.getLastName() + ", " + employee.getFirstName(), employee.getPaycheck());
            }
        }
        System.out.println("End of Payroll");
    }
}
