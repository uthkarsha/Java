package csi213Project02;

import java.util.Scanner;

/**
 * {@code CreateEmployee} handles the creation of various types of employees and adds them to the payroll.
 */
public class CreateEmployee {
    private Scanner scanner = new Scanner(System.in);

    /**
     * Executes the employee creation process and adds them to the payroll.
     *
     * @param employees Array of employees to be added to.
     * @param payroll Reference to the payroll system to add the new employee.
     */
    public void execute(Employee[] employees, Payroll payroll) {
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter Employee Type (Salaried, Commissioned, Hourly): ");
        String type = scanner.nextLine().toLowerCase();

        switch (type) {
            case "hourly" -> {
                System.out.print("Enter Pay Rate: ");
                float payRate = scanner.nextFloat();
                payroll.addEmployee(new HourlyEmployee(firstName, lastName, payRate));
            }
            case "salaried" -> {
                System.out.print("Enter Yearly Salary: ");
                float salary = scanner.nextFloat();
                payroll.addEmployee(new SalariedEmployee(firstName, lastName, salary));
            }
            case "commissioned" -> {
                System.out.print("Enter Yearly Base Salary: ");
                float baseSalary = scanner.nextFloat();
                System.out.print("Enter Number of Units in Commission Schedule: ");
                int numSchedules = scanner.nextInt();
                float[][] schedule = new float[numSchedules][2];
                for (int i = 0; i < numSchedules; i++) {
                    System.out.print("Enter units and commission rate (separated by space): ");
                    schedule[i][0] = scanner.nextFloat();
                    schedule[i][1] = scanner.nextFloat();
                }
                payroll.addEmployee(new CommissionedEmployee(firstName, lastName, baseSalary, schedule));
            }
            default -> System.out.println("Invalid Employee Type");
        }
    }
}
